conversion_rate = 1.25
pounds = float(input("Please enter amount in pounds: £"))
dollars = pounds * conversion_rate
print(f"£{pounds} are ${dollars:.2f}")