days_in_year=365
minutes_in_hours=60
hours_in_day=24
print("This code is to get the number of minutes in a year")
minutes_in_year=days_in_year*minutes_in_hours*hours_in_day
print(minutes_in_year)
		     
