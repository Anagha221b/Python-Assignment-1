name=input()
print(f"Hi {name}, welcome to Python programming :)")
